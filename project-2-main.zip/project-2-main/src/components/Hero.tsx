import React from 'react';
import { Button } from './Button';
import { MousePointer, ShieldCheck } from 'lucide-react';

export const Hero: React.FC = () => {
  const scrollToPricing = () => {
    document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative pt-24 pb-16 sm:pt-32 sm:pb-20 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-indigo-900/20 to-transparent pointer-events-none"></div>
      
      {/* Animated circles decoration */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-purple-600/30 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute -bottom-48 -right-24 w-80 h-80 bg-indigo-600/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-center lg:space-x-12">
          <div className="lg:w-1/2 mb-12 lg:mb-0">
            <div className="inline-block px-4 py-1 bg-indigo-900/50 rounded-full text-indigo-300 text-sm font-medium mb-6 animate-fadeIn">
              ⚡ Impulsione seu perfil nas redes sociais
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight">
              <span className="block text-white">Ganhe</span>
              <span className="bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">Seguidores Reais</span>
              <span className="block text-white">em Minutos!</span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-2xl">
              Impulsione seu perfil no Instagram com seguidores 100% brasileiros, reais e ativos.
            </p>

            {/* Progress bar showing today's delivered followers */}
            <div className="mb-8">
              <div className="flex justify-between text-sm text-gray-400 mb-2">
                <span>Seguidores entregues hoje</span>
                <span className="font-medium">78%</span>
              </div>
              <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full animate-pulse"
                  style={{ width: '78%' }}
                ></div>
              </div>
              <p className="text-sm text-indigo-400 mt-2">
                <span className="font-bold">127,492</span> seguidores entregues nas últimas 24h
              </p>
            </div>
            
            <div className="flex flex-col space-y-4 mb-8">
              <Button 
                size="lg" 
                icon={<MousePointer size={20} />}
                onClick={scrollToPricing}
                className="text-lg py-4 px-8"
              >
                Ganhar Seguidores Agora
              </Button>
              
              <div className="flex items-left justify-left space-x-2 text-green-400">
                <ShieldCheck className="w-5 h-5" />
                <span className="font-medium">Entrega 100% garantida</span>
              </div>
            </div>
            
            <div className="flex items-center text-gray-400 text-sm">
              <span className="mr-3">Mais de 30.000 clientes satisfeitos</span>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg key={star} className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2 relative">
            <div className="relative mx-auto max-w-xs sm:max-w-sm">
              {/* Phone mockup */}
              <div className="relative rounded-[2.5rem] border-8 border-gray-800 h-[580px] w-[280px] mx-auto overflow-hidden shadow-2xl">
                <div className="absolute top-0 inset-x-0 h-6 bg-gray-800 rounded-b-lg"></div>
                
                <div className="h-full w-full bg-white overflow-hidden relative">
                  {/* Instagram-like header */}
                  <div className="bg-white border-b border-gray-200">
                    <div className="flex justify-between items-center px-4 py-3">
                      <div className="text-black font-semibold">seu_perfil</div>
                      <div className="flex space-x-4">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                      </div>
                    </div>
                  </div>
                  
                  {/* Profile section */}
                  <div className="px-4 py-4">
                    <div className="flex items-center">
                      <div className="w-20 h-20 rounded-full border-2 border-pink-500 p-0.5">
                        <div className="w-full h-full rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500"></div>
                      </div>
                      <div className="flex-1 ml-4">
                        <div className="grid grid-cols-3 gap-2 text-center">
                          <div>
                            <div className="font-bold text-black">1.458</div>
                            <div className="text-xs text-gray-500">Posts</div>
                          </div>
                          <div className="relative">
                            <div className="font-bold text-black animate-pulse">10.4K</div>
                            <div className="text-xs text-gray-500">Seguidores</div>
                            <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-1 rounded">
                              +1K
                            </div>
                          </div>
                          <div>
                            <div className="font-bold text-black">526</div>
                            <div className="text-xs text-gray-500">Seguindo</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <div className="font-bold text-black">Seu Nome</div>
                      <div className="text-sm text-gray-900">✨ Criador de conteúdo</div>
                      <div className="text-sm text-blue-500">www.seusite.com.br</div>
                    </div>
                    
                    <button className="w-full mt-3 bg-gray-100 text-black font-semibold py-1.5 rounded-md text-sm">
                      Editar perfil
                    </button>
                  </div>
                  
                  {/* Grid posts preview */}
                  <div className="grid grid-cols-3 gap-0.5 mt-2 bg-gray-100">
                    {[...Array(9)].map((_, i) => (
                      <div key={i} className="aspect-square bg-gray-200"></div>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Floating elements */}
              <div className="absolute -right-4 top-1/4 bg-white p-3 rounded-lg shadow-xl animate-float">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center text-white font-bold text-sm">+</div>
                  <div className="text-sm font-medium text-gray-900">1.000 seguidores</div>
                </div>
              </div>
              
              <div className="absolute -left-6 bottom-1/4 bg-white p-3 rounded-lg shadow-xl animate-float" style={{ animationDelay: '1s' }}>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex-shrink-0 flex items-center justify-center text-white font-bold text-sm">+</div>
                  <div className="text-sm font-medium text-gray-900">5.000 curtidas</div>
                </div>
              </div>

              {/* Delivery status indicator */}
              <div className="absolute -right-4 bottom-8 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg animate-pulse">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-sm font-medium">Entrega em minutos</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};