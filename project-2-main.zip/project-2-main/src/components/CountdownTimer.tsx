import React, { useState, useEffect } from 'react';

interface TimeLeft {
  hours: number;
  minutes: number;
  seconds: number;
}

export const CountdownTimer: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>(() => {
    const now = new Date();
    // Round up to the next hour and add 15 hours
    const nextHour = new Date(now);
    nextHour.setHours(nextHour.getHours() + 1, 0, 0, 0);
    const expiration = new Date(nextHour.getTime() + 14 * 60 * 60 * 1000);
    
    const difference = expiration.getTime() - now.getTime();
    return {
      hours: Math.floor(difference / (1000 * 60 * 60)),
      minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
      seconds: Math.floor((difference % (1000 * 60)) / 1000)
    };
  });

  const [expirationTime] = useState(() => {
    const now = new Date();
    // Round up to the next hour and add 15 hours
    const nextHour = new Date(now);
    nextHour.setHours(nextHour.getHours() + 1, 0, 0, 0);
    return new Date(nextHour.getTime() + 14 * 60 * 60 * 1000);
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const difference = expirationTime.getTime() - now.getTime();
      
      if (difference <= 0) {
        clearInterval(timer);
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const hours = Math.floor(difference / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ hours, minutes, seconds });
    }, 1000);

    return () => clearInterval(timer);
  }, [expirationTime]);

  const formatNumber = (num: number): string => num.toString().padStart(2, '0');

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  return (
    <div className="relative overflow-hidden rounded-xl">
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-800 via-indigo-700 to-purple-800 animate-gradient opacity-90"></div>
      
      {/* Content */}
      <div className="relative py-4 px-6">
        <div className="flex flex-col items-center justify-center space-y-4">
          <h3 className="text-xl sm:text-2xl font-bold text-white text-center tracking-wide">
            TODOS OS PLANOS COM 30% DE DESCONTO
          </h3>
          
          <div className="flex items-center justify-center space-x-4">
            <div className="bg-purple-900/50 backdrop-blur-sm rounded-lg px-4 py-3 border border-purple-500/20">
              <div className="font-mono text-4xl sm:text-6xl font-bold text-white tabular-nums">
                {formatNumber(timeLeft.hours)}
              </div>
            </div>
            <span className="text-4xl sm:text-6xl font-bold text-white animate-pulse">:</span>
            <div className="bg-purple-900/50 backdrop-blur-sm rounded-lg px-4 py-3 border border-purple-500/20">
              <div className="font-mono text-4xl sm:text-6xl font-bold text-white tabular-nums">
                {formatNumber(timeLeft.minutes)}
              </div>
            </div>
            <span className="text-4xl sm:text-6xl font-bold text-white animate-pulse">:</span>
            <div className="bg-purple-900/50 backdrop-blur-sm rounded-lg px-4 py-3 border border-purple-500/20">
              <div className="font-mono text-4xl sm:text-6xl font-bold text-white tabular-nums">
                {formatNumber(timeLeft.seconds)}
              </div>
            </div>
          </div>

          <p className="text-sm sm:text-base text-purple-200 font-medium">
            Essa oferta expira em {formatDate(expirationTime)} às {expirationTime.getHours()}h
          </p>
        </div>
      </div>
    </div>
  );
};