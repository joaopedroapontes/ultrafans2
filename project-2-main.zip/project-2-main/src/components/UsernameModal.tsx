import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Check, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from './Button';

interface UsernameModalProps {
  isOpen: boolean;
  onClose: () => void;
  platform: 'instagram' | 'tiktok';
  planTitle: string;
  amount: number;
  price: number;
}

export const UsernameModal: React.FC<UsernameModalProps> = ({
  isOpen,
  onClose,
  platform,
  planTitle,
  amount,
  price
}) => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [isValid, setIsValid] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (username) {
      if (username.includes('http') || username.includes('instagram.com')) {
        setIsValid(false);
        setError('Por favor, digite apenas o nome de usuário sem o link completo');
        return;
      }

      const sanitizedUsername = username.replace(/@/g, '').trim().toLowerCase();
      const isValidUsername = /^[a-z0-9._]{1,30}$/.test(sanitizedUsername);
      
      setIsValid(isValidUsername);
      setError(isValidUsername ? null : 'Use apenas letras minúsculas, números, pontos e underscores');
    } else {
      setIsValid(null);
      setError(null);
    }
  }, [username]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isValid) {
      setIsLoading(true);
      
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      navigate('/payment', {
        state: {
          username: username.replace(/@/g, '').trim().toLowerCase(),
          planTitle,
          amount,
          platform,
          price
        }
      });
      
      setIsLoading(false);
      onClose();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.toLowerCase();
    setUsername(value);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/50">
      <div className="relative w-full max-w-md bg-white rounded-xl shadow-2xl">
        <button
          onClick={onClose}
          className="absolute -top-2 -right-2 bg-gray-800 text-white rounded-full p-1.5 hover:bg-gray-700 transition-colors"
          disabled={isLoading}
        >
          <X size={20} />
        </button>

        <div className="p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-2">
            Instagram • {planTitle}
          </h3>
          <p className="text-sm text-gray-600 mb-6">
            {amount.toLocaleString()} seguidores
          </p>

          <form onSubmit={handleSubmit}>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Digite seu @ do Instagram
            </label>
            
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <span className="text-gray-500">@</span>
              </div>
              <input
                type="text"
                value={username}
                onChange={handleInputChange}
                disabled={isLoading}
                className={`block w-full pl-8 pr-10 py-2.5 text-gray-900 border rounded-lg focus:outline-none focus:ring-2 ${
                  isValid === true
                    ? 'border-green-500 focus:ring-green-500'
                    : isValid === false
                    ? 'border-red-500 focus:ring-red-500'
                    : 'border-gray-300 focus:ring-indigo-500'
                } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                placeholder="exemplo.perfil"
              />
              {isValid !== null && !isLoading && (
                <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                  {isValid ? (
                    <Check className="w-5 h-5 text-green-500" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-500" />
                  )}
                </div>
              )}
            </div>

            {error && (
              <p className="mt-2 text-sm text-red-600">
                {error}
              </p>
            )}

            <div className="mt-6">
              {isLoading ? (
                <div className="bg-indigo-600 text-white rounded-lg py-2 text-center">
                  <div className="flex items-center justify-center gap-2">
                    <Loader2 size={20} className="animate-spin" />
                    <span className="text-sm">Tudo pronto! Você será redirecionado ao pagamento</span>
                  </div>
                </div>
              ) : (
                <Button
                  type="submit"
                  disabled={!isValid}
                  fullWidth
                  className={!isValid ? 'opacity-50 cursor-not-allowed' : ''}
                >
                  Continuar
                </Button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};