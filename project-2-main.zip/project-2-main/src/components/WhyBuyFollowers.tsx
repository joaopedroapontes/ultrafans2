import React from 'react';
import { Target, Users, Rocket, Award } from 'lucide-react';

interface ReasonCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  highlight?: string;
}

const ReasonCard: React.FC<ReasonCardProps> = ({ icon, title, description, highlight }) => {
  return (
    <div className="bg-gray-800/50 rounded-xl p-6 transition-all duration-300 hover:bg-gray-800">
      <div className="w-14 h-14 bg-indigo-600/20 rounded-xl flex items-center justify-center mb-4 text-indigo-400">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3 text-white">{title}</h3>
      <p className="text-gray-300">
        {description}
        {highlight && <span className="font-semibold text-indigo-400"> {highlight}</span>}
      </p>
    </div>
  );
};

export const WhyBuyFollowers: React.FC = () => {
  const reasons = [
    {
      icon: <Award size={28} />,
      title: "Construa autoridade e credibilidade",
      description: "Faça com que as pessoas tenham mais confiança em você, no seu discurso e no seu produto"
    },
    {
      icon: <Target size={28} />,
      title: "Tenha um perfil forte",
      description: "Salte degraus no jogo da atenção.",
      highlight: "Perfis grandes atraem mais cliques, olhares e respeito — mesmo antes de abrir a boca. Use isso para criar uma audiência forte e interessada no que você tem a dizer."
    },
    {
      icon: <Users size={28} />,
      title: "Crie sua própria vitrine",
      description: "Com seguidores certos, o perfil vira uma vitrine que gira oportunidades todos os dias. Parceiros, clientes, convites —",
      highlight: "as pessoas passam a vir até você."
    },
    {
      icon: <Rocket size={28} />,
      title: "Cresça de maneira rápida e ganhe tempo",
      description: "Você sabe que pode até ter um bom conteúdo, mas levaria 2 anos pra atingir 10k seguidores orgânicos. E o tempo não volta. Por isso, compre tempo: ganhe tração agora e foque onde realmente importa: vender, influenciar e escalar."
    }
  ];

  return (
    <section className="py-16 sm:py-24 bg-gray-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
            Por que adquirir seguidores?
          </h2>
          <p className="text-xl text-gray-300">
            Descubra como nossos serviços podem impulsionar sua presença online
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 max-w-7xl mx-auto">
          {reasons.map((reason, index) => (
            <ReasonCard
              key={index}
              icon={reason.icon}
              title={reason.title}
              description={reason.description}
              highlight={reason.highlight}
            />
          ))}
        </div>
      </div>
    </section>
  );
};