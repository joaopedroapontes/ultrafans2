import React from 'react';
import { CreditCard, User, Rocket, Shield, MousePointer } from 'lucide-react';
import { Button } from './Button';

interface StepProps {
  number: number;
  title: string;
  description: string;
  icon: React.ReactNode;
}

const Step: React.FC<StepProps> = ({ number, title, description, icon }) => {
  return (
    <div className="flex flex-col items-center text-center group relative\" data-aos="fade-up">
      <div className="relative mb-6">
        {/* Animated background */}
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-indigo-500/20 rounded-xl blur-xl animate-pulse"></div>
        
        {/* Icon container */}
        <div className="relative w-20 h-20 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center text-white shadow-xl">
          {icon}
        </div>
        
        {/* Number indicator */}
        <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white text-sm font-bold border-2 border-gray-900">
          {number}
        </div>
      </div>
      
      <h3 className="text-white text-xl font-bold mb-3 tracking-wide">{title}</h3>
      <p className="text-gray-300 max-w-[250px] leading-relaxed">{description}</p>
      
      {/* Connecting line */}
      {number < 4 && (
        <div className="hidden md:block absolute top-10 left-[60%] w-[calc(100%-40px)] h-[2px]">
          <div className="w-full h-full bg-gradient-to-r from-purple-500 to-indigo-500 transform origin-left scale-x-0 animate-expandLine"></div>
        </div>
      )}
    </div>
  );
};

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      number: 1,
      title: 'Escolha seu pacote',
      description: 'Selecione o plano ideal para alcançar seus objetivos no Instagram',
      icon: <Shield size={32} />
    },
    {
      number: 2,
      title: 'Digite seu @',
      description: 'Informe seu usuário do Instagram (não precisa de senha)',
      icon: <User size={32} />
    },
    {
      number: 3,
      title: 'Pagamento Seguro',
      description: 'Realize o pagamento de maneira rápida e segura',
      icon: <CreditCard size={32} />
    },
    {
      number: 4,
      title: 'Crescimento Imediato',
      description: 'Veja seu perfil crescer em questão de minutos',
      icon: <Rocket size={32} />
    }
  ];

  const scrollToPricing = () => {
    document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-16 sm:py-24 bg-gray-950 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-500/5 to-transparent"></div>
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
            Como funciona?
          </h2>
          <p className="text-lg text-gray-300 tracking-wide max-w-xl mx-auto">
            Crescer no Instagram nunca foi tão simples. Siga estes passos e comece a ver resultados em minutos.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 lg:gap-8 max-w-6xl mx-auto mb-16">
          {steps.map((step) => (
            <Step
              key={step.number}
              number={step.number}
              title={step.title}
              description={step.description}
              icon={step.icon}
            />
          ))}
        </div>

        <div className="text-center">
          <Button 
            variant="primary" 
            size="lg" 
            onClick={scrollToPricing}
            icon={<MousePointer size={18} />}
          >
            Ganhar Seguidores Agora
          </Button>
        </div>
      </div>
    </section>
  );
};