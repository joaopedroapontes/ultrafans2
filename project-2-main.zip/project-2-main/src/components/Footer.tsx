import React, { useState } from 'react';
import { MessageCircle, Mail, Shield } from 'lucide-react';
import { TermsModal } from './TermsModal';
import { PrivacyModal } from './PrivacyModal';

export const Footer: React.FC = () => {
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);

  return (
    <footer className="bg-gray-950 relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <img 
                src="https://i.postimg.cc/5tggFbvy/Colorful-Modern-Infinity-Technology-Free-Logo-5.png"
                alt="Ultra Fans Logo"
                className="w-8 h-8 object-contain"
              />
              <div className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-indigo-600 bg-clip-text text-transparent">
                Ultra Fans
              </div>
            </div>
            <p className="text-gray-400 mb-4">
              Potencialize sua presença no Instagram com seguidores de qualidade.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold text-white text-lg mb-4">Links Úteis</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Sobre Nós</a></li>
              <li><a href="#testimonials" className="text-gray-400 hover:text-white transition-colors">Depoimentos</a></li>
              <li><a href="#faq" className="text-gray-400 hover:text-white transition-colors">FAQ</a></li>
              <li>
                <button
                  onClick={() => setIsTermsOpen(true)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Termos de Uso
                </button>
              </li>
              <li>
                <button
                  onClick={() => setIsPrivacyOpen(true)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Política de Privacidade
                </button>
              </li>
            </ul>
          </div>
          
          <div className="md:col-span-1">
            <h3 className="font-semibold text-white text-lg mb-4">Contato</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex items-center">
                  <Mail className="w-5 h-5 text-indigo-400 mr-3" />
                  <span className="text-gray-400">suporte.ultrafans@gmail.com</span>
                </div>
              </div>
              <div className="flex items-start">
                <MessageCircle className="w-5 h-5 text-indigo-400 mt-1 mr-3" />
                <span className="text-gray-400">Suporte 24h</span>
              </div>
              <div className="flex items-start">
                <Shield className="w-5 h-5 text-indigo-400 mt-1 mr-3" />
                <span className="text-gray-400">Compra 100% segura e garantida</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-500 text-sm mb-4 md:mb-0">
              <p>&copy; {new Date().getFullYear()} Ultra Fans. Todos os direitos reservados.</p>
              <p className="mt-2">
                LLC Desenvolvimento Digital LTDA<br />
                CNPJ: 58.455.659/0001-12
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <TermsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />
      <PrivacyModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
    </footer>
  );
};