import React from 'react';
import { Counter } from './Counter';

export const SocialProof: React.FC = () => {
  return (
    <section className="py-8 sm:py-16 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/30 to-purple-900/30"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
            <div className="text-center">
              <div className="text-3xl sm:text-4xl font-bold text-white mb-2">
                <Counter from={0} to={30} suffix="k+" duration={2000} />
              </div>
              <p className="text-indigo-300">Clientes Satisfeitos</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl sm:text-4xl font-bold text-white mb-2">
                <Counter from={0} to={12} suffix="M+" duration={2500} />
              </div>
              <p className="text-indigo-300">Seguidores Entregues</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl sm:text-4xl font-bold text-white mb-2">
                <Counter from={0} to={100} suffix="%" duration={1500} />
              </div>
              <p className="text-indigo-300">Taxa de Sucesso</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl sm:text-4xl font-bold text-white mb-2">
                <Counter from={0} to={24} suffix="/7" duration={1800} />
              </div>
              <p className="text-indigo-300">Suporte Disponível</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};