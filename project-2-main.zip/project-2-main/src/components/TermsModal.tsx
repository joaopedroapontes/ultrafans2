import React from 'react';
import { X } from 'lucide-react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TermsModal: React.FC<TermsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="relative w-full max-w-4xl h-[90vh] bg-white rounded-xl shadow-2xl flex flex-col">
        <div className="sticky top-0 z-10 flex justify-between items-center p-4 border-b border-gray-200 bg-white rounded-t-xl">
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Termos de Uso</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors p-2"
            aria-label="Fechar"
          >
            <X size={24} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="prose prose-sm sm:prose max-w-none text-gray-600">
            <p className="text-sm text-gray-500 mb-4">Última atualização: Maio de 2025</p>
            
            <p className="mb-6">
              Seja bem-vindo à Ultra Fans, uma plataforma operada por LLC Desenvolvimento Digital LTDA,
              inscrita no CNPJ sob o nº 58.455.659/0001-12, doravante denominada "Ultra Fans" ou "Plataforma".
            </p>
            
            <p className="mb-6">
              Ao acessar e utilizar os serviços oferecidos pela Ultra Fans, o usuário declara estar ciente,
              de acordo e vinculado aos presentes Termos de Uso. Caso não concorde com qualquer disposição
              deste documento, recomenda-se que não utilize os serviços da Plataforma.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">1. Objeto</h3>
            <p>
              A Ultra Fans oferece serviços digitais de entrega de engajamento para redes sociais,
              compreendendo compra de seguidores para Instagram, TikTok, YouTube e outras plataformas compatíveis;
            </p>
            <p>
              Todos os serviços são disponibilizados por meio de integração com APIs externas e fornecidos
              sob demanda, mediante solicitação e pagamento do usuário.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">2. Elegibilidade e Aceitação</h3>
            <p>
              2.1. A utilização da Plataforma é permitida a qualquer pessoa física ou jurídica, nacional
              ou estrangeira, não sendo estabelecida idade mínima, embora se recomende o uso por maiores
              de 18 anos ou com autorização dos responsáveis legais.
            </p>
            <p>
              2.2. O uso da Plataforma implica aceitação plena e irrestrita dos presentes Termos de Uso.
              A Ultra Fans poderá, a seu exclusivo critério, alterar o conteúdo deste documento a qualquer
              momento, sem aviso prévio.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">3. Serviços e Funcionamento</h3>
            <p>3.1. Os serviços são oferecidos de forma avulsa, sem planos de assinatura ou recorrência.</p>
            <p>
              3.2. A entrega pode ocorrer em até 24 horas após a confirmação do pagamento, dependendo do
              volume adquirido.
            </p>
            <p>
              3.3. Em caso de perda de seguidores após a entrega, será aplicado um refill automático no
              período de até 60 dias.
            </p>
            <p>
              3.4. O usuário declara compreender que os serviços prestados têm caráter promocional e de
              visibilidade, não constituindo garantia de crescimento orgânico, engajamento real ou
              resultado comercial.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">4. Política de Reembolso</h3>
            <p>
              4.1. O usuário poderá solicitar reembolso integral no prazo de 7 (sete) dias corridos a
              contar da data da compra, desde que o serviço ainda não tenha sido entregue ou que haja
              falha técnica identificável.
            </p>
            <p>
              4.2. Após a entrega do serviço, não haverá reembolso parcial ou integral, salvo em casos
              comprovados de falha na prestação.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">5. Condutas Proibidas</h3>
            <p>É terminantemente proibido:</p>
            <p>
              5.1. Utilizar os serviços da Ultra Fans para perfis que não sejam de titularidade ou
              gerência direta do usuário;
            </p>
            <p>
              5.2. Promover o uso fraudulento, abusivo ou contrário aos termos e políticas das redes
              sociais;
            </p>
            <p>
              5.3. Tentar revender ou redistribuir os serviços adquiridos sem autorização formal da
              Ultra Fans;
            </p>
            <p>5.4. Inserir dados falsos ou de terceiros no momento da compra.</p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">6. Isenção de Responsabilidade</h3>
            <p>
              6.1. A Plataforma não garante o desempenho contínuo e ininterrupto dos serviços,
              considerando que a execução depende de sistemas de terceiros (APIs externas).
            </p>
            <p>
              6.2. O usuário é o único responsável pelo uso dos serviços, inclusive quanto à inserção
              de links corretos e dados precisos durante o processo de compra.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">7. Dados Pessoais e Privacidade</h3>
            <p>
              7.1. Para processar pedidos, a Ultra Fans coleta nome, e-mail e CPF dos usuários,
              exclusivamente no momento do checkout.
            </p>
            <p>
              7.2. Não há criação de contas ou login. Os dados coletados são armazenados por tempo
              indeterminado para fins fiscais e de segurança, conforme a Lei Geral de Proteção de
              Dados (Lei 13.709/18).
            </p>
            <p>
              7.3. A Ultra Fans não compartilha dados com terceiros, tampouco utiliza cookies de
              rastreamento ou ferramentas de análise de comportamento.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">8. Alterações dos Termos</h3>
            <p>
              8.1. A Ultra Fans poderá modificar, a qualquer momento, o conteúdo destes Termos de Uso.
            </p>
            <p>
              8.2. Como não há sistema de conta ou login, os usuários não serão notificados
              individualmente. Recomenda-se a leitura periódica dos Termos diretamente no site da
              plataforma.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">9. Disposições Finais</h3>
            <p>
              9.1. O uso da plataforma presume boa-fé, sendo vedado qualquer uso com fins ilícitos,
              imorais ou que infrinjam a legislação brasileira ou diretrizes de uso das redes sociais.
            </p>
            <p>
              9.2. O presente documento entra em vigor na data de sua publicação, em Março de 2025,
              substituindo qualquer versão anterior.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};