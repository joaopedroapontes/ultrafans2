import React from 'react';
import { PlanCard } from './PlanCard';
import { plans } from '../data/plans';
import { CountdownTimer } from './CountdownTimer';

export const PricingSection: React.FC = () => {
  return (
    <section id="pricing" className="pt-24 sm:pt-32 pb-8 sm:pb-16 relative bg-gray-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-12">
          <CountdownTimer />
          
          <h2 className="text-3xl sm:text-4xl font-bold mt-8 mb-4 sm:mb-6 bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
            Escolha o melhor plano para seu perfil
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 mb-8">
            Aumente seus seguidores em minutos com nossos pacotes acessíveis e de alta qualidade
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans.instagram.map((plan, index) => (
            <PlanCard
              key={`instagram-${index}`}
              platform="instagram"
              title={plan.title}
              price={plan.price}
              amount={plan.amount}
              features={plan.features}
              popular={plan.popular}
              description={plan.description}
              emoji={plan.emoji}
              targetEmoji={plan.targetEmoji}
            />
          ))}
        </div>
      </div>
    </section>
  );
};