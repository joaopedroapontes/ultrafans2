import React, { useState } from 'react';
import { Button } from './Button';
import { Check } from 'lucide-react';
import { InstagramIcon } from './SocialIcons';
import { UsernameModal } from './UsernameModal';

interface PlanCardProps {
  platform: 'instagram' | 'tiktok' | 'youtube';
  title: string;
  price: number;
  amount: number;
  features: string[];
  popular?: boolean;
  description?: string;
  emoji?: string;
  targetEmoji?: string;
}

export const PlanCard: React.FC<PlanCardProps> = ({
  platform,
  title,
  price,
  amount,
  features,
  popular = false,
  description,
  emoji,
  targetEmoji
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const platformIcons = {
    instagram: <InstagramIcon className="w-6 h-6" />,
    tiktok: null,
    youtube: null
  };
  
  const platformColors = {
    instagram: 'from-pink-500 to-purple-600',
    tiktok: 'from-cyan-500 to-blue-600',
    youtube: 'from-red-500 to-red-600'
  };

  const platformType = {
    instagram: 'seguidores',
    tiktok: 'seguidores',
    youtube: 'inscritos'
  };

  // Calculate original price (30% more than the discounted price)
  const originalPrice = Math.ceil(price / 0.7);

  return (
    <>
      <div className="relative h-full">
        {popular && (
          <div className="absolute -top-4 inset-x-0 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-medium py-1.5 text-center rounded-t-lg">
            Mais Popular
          </div>
        )}
        
        <div className={`h-full rounded-2xl overflow-hidden transition-all duration-300 ${
          popular 
            ? 'bg-gradient-to-b from-indigo-900 to-indigo-800 shadow-xl shadow-indigo-500/20' 
            : 'bg-gray-800 hover:shadow-lg hover:shadow-indigo-500/10'
        }`}>
          <div className="p-6 flex flex-col h-full">
            <div className="flex items-center mb-4">
              <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${platformColors[platform]} flex items-center justify-center mr-3`}>
                {platformIcons[platform]}
              </div>
              <div className="flex items-center">
                <span className="mr-2 text-xl">{emoji}</span>
                <h3 className="text-xl font-bold text-white">{title}</h3>
              </div>
            </div>
            
            <div className="mb-4">
              <div className="flex items-baseline">
                <p className="text-3xl font-bold text-white">
                  R$ {price.toFixed(2)}
                </p>
                <span className="ml-2 text-sm line-through text-gray-400">
                  R$ {originalPrice.toFixed(2)}
                </span>
              </div>
              <p className="text-sm font-medium text-indigo-300 mt-1">
                {amount.toLocaleString()} {platformType[platform]}
              </p>
              <p className="text-sm font-normal text-green-400 mt-1">30% OFF</p>
            </div>

            {description && (
              <div className="text-sm text-gray-300 mb-4 bg-gray-800/50 p-3 rounded-lg border border-gray-700/50">
                <p className="flex items-center gap-2">
                  <span className="text-lg">{targetEmoji}</span>
                  {description}
                </p>
              </div>
            )}
            
            <div className="space-y-2.5 mb-6 flex-grow">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start">
                  <div className="mr-2 mt-0.5 text-green-400">
                    <Check size={16} />
                  </div>
                  <span className="text-sm text-gray-300">{feature}</span>
                </div>
              ))}
            </div>
            
            <Button 
              variant={popular ? "primary" : "outline"} 
              fullWidth
              onClick={() => setIsModalOpen(true)}
            >
              Comprar Agora
            </Button>
          </div>
        </div>
      </div>

      {(platform === 'instagram' || platform === 'tiktok') && (
        <UsernameModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          platform={platform}
          planTitle={title}
          amount={amount}
          price={price}
        />
      )}
    </>
  );
};