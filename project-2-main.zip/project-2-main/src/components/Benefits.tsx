import React from 'react';
import { Zap, ShieldCheck, Lock, HeadphonesIcon } from 'lucide-react';

interface BenefitProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const Benefit: React.FC<BenefitProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-gray-800 rounded-xl p-4 sm:p-6 transition-all duration-300 hover:bg-gray-700 hover:shadow-lg hover:shadow-indigo-500/10">
      <div className="w-12 h-12 bg-indigo-600/20 rounded-xl flex items-center justify-center mb-4 text-indigo-400">
        {icon}
      </div>
      <h3 className="text-lg sm:text-xl font-bold mb-2 text-white">{title}</h3>
      <p className="text-sm sm:text-base text-gray-300">{description}</p>
    </div>
  );
};

export const Benefits: React.FC = () => {
  const benefits = [
    {
      icon: <Zap size={24} />,
      title: 'Entrega Rápida',
      description: 'Receba seus seguidores em minutos, sem esperas ou complicações.'
    },
    {
      icon: <ShieldCheck size={24} />,
      title: 'Totalmente Seguro',
      description: 'Sistema 100% seguro e discreto. Seus dados estão protegidos.'
    },
    {
      icon: <Lock size={24} />,
      title: 'Sem Senha',
      description: 'Não solicitamos senhas ou acesso às suas contas em momento algum.'
    },
    {
      icon: <HeadphonesIcon size={24} />,
      title: 'Suporte 24h',
      description: 'Atendimento rápido e eficiente em todos os dias da semana.'
    }
  ];

  return (
    <section id="benefits" className="py-8 sm:py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
            Por que escolher nossos serviços?
          </h2>
          <p className="text-lg sm:text-xl text-gray-300">
            Oferecemos as melhores soluções para aumentar sua presença online com rapidez e segurança.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
          {benefits.map((benefit, index) => (
            <Benefit
              key={index}
              icon={benefit.icon}
              title={benefit.title}
              description={benefit.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};