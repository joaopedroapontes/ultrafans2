import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';

const maleNames = [
  'Arthur', 'Miguel', 'Heitor', 'Davi', 'Bernardo', 'Gabriel', 'Samuel',
  'Matheus', 'Rafael', 'Enzo', 'Pedro', 'Lucas', 'Gustavo', 'João',
  'Leonardo', 'Daniel', 'Bruno', 'Caio', 'Vinícius', 'Eduardo'
];

const femaleNames = [
  'Helena', 'Alice', 'Laura', 'Valentina', 'Sophia', 'Isabella', 'Manuela',
  'Júlia', 'Luna', 'Maria Clara', 'Beatriz', 'Ana', 'Lívia', 'Rafaela',
  'Clara', 'Melissa', 'Gabriela', 'Yasmin', 'Larissa', 'Camila'
];

const allNames = [...maleNames, ...femaleNames];

const getRandomName = () => allNames[Math.floor(Math.random() * allNames.length)];

interface Purchase {
  name: string;
  amount: number;
  type: string;
  platform: string;
}

const generateRandomPurchase = (): Purchase => {
  const platforms = ['Instagram'];
  const types = {
    'Instagram': 'seguidores',
  };
  const amounts = [500, 1000, 2000, 3000, 5000, 10000];
  
  const platform = platforms[Math.floor(Math.random() * platforms.length)];
  
  return {
    name: getRandomName(),
    amount: amounts[Math.floor(Math.random() * amounts.length)],
    type: types[platform as keyof typeof types],
    platform
  };
};

export const RecentPurchase: React.FC = () => {
  const [purchase, setPurchase] = useState(generateRandomPurchase());
  const [visible, setVisible] = useState(false);
  const [shouldStart, setShouldStart] = useState(false);

  useEffect(() => {
    // Initial delay of 15 seconds before showing first notification
    const initialDelay = setTimeout(() => {
      setShouldStart(true);
      setVisible(true);
    }, 15000);

    return () => clearTimeout(initialDelay);
  }, []);

  useEffect(() => {
    if (!shouldStart) return;

    // Timer to hide notification after 3 seconds
    const hideTimer = setTimeout(() => {
      setVisible(false);
    }, 3000);

    // Timer to show new notification every 30 seconds
    const showTimer = setInterval(() => {
      setPurchase(generateRandomPurchase());
      setVisible(true);
    }, 30000);
    
    return () => {
      clearTimeout(hideTimer);
      clearInterval(showTimer);
    };
  }, [purchase, shouldStart]); // Reset timers when purchase changes or shouldStart changes

  if (!visible) return null;

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[9999] bg-white rounded-lg shadow-lg p-3 max-w-[280px] w-full mx-4 animate-slideInDown">
      <button
        onClick={() => setVisible(false)}
        className="absolute -top-2 -right-2 bg-gray-800 text-white rounded-full p-1 hover:bg-gray-700 transition-colors"
      >
        <X size={16} />
      </button>
      
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex-shrink-0 flex items-center justify-center text-white font-bold">
          {purchase.name.charAt(0)}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-gray-900 font-medium text-sm truncate">
            {purchase.name}
          </p>
          <p className="text-xs text-gray-600 truncate">
            {purchase.amount.toLocaleString()} {purchase.type} • {purchase.platform}
          </p>
          <p className="text-xs text-green-600 font-medium">
            agora mesmo
          </p>
        </div>
      </div>
    </div>
  );
};