import React from 'react';
import { testimonials } from '../data/testimonials';
import { Button } from './Button';
import { MousePointer } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const scrollToPricing = () => {
    document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="testimonials" className="py-8 sm:py-16 bg-gray-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
            O que nossos clientes dizem
          </h2>
          <p className="text-lg sm:text-xl text-gray-300">
            Veja o depoimento de profissionais que impulsionaram sua presença online com nossos serviços
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-12">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-800/50 rounded-xl p-6 transition-all duration-300 hover:bg-gray-800">
              <div className="flex flex-col h-full">
                <div className="mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg key={star} className="inline-block w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                
                <blockquote className="mb-6 flex-1 text-gray-300 italic">
                  "{testimonial.comment}"
                </blockquote>
                
                <div className="flex items-center mt-auto">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                    <img src={testimonial.avatar} alt={testimonial.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <div className="font-semibold text-white">{testimonial.name}</div>
                    <div className="text-sm text-indigo-300">{testimonial.profession}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button 
            variant="primary" 
            size="lg" 
            onClick={scrollToPricing}
            icon={<MousePointer size={18} />}
          >
            Ganhar Seguidores Agora
          </Button>
        </div>
      </div>
    </section>
  );
};