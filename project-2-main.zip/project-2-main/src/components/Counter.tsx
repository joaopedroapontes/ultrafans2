import React, { useEffect, useState, useRef } from 'react';

interface CounterProps {
  from: number;
  to: number;
  duration?: number;
  suffix?: string;
}

export const Counter: React.FC<CounterProps> = ({
  from,
  to,
  duration = 2000,
  suffix = ''
}) => {
  const [count, setCount] = useState(from);
  const countRef = useRef<number>(from);
  const timerRef = useRef<number | null>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          startAnimation();
        }
      },
      { threshold: 0.1 }
    );
    
    const element = document.getElementById(`counter-${to}`);
    if (element) observer.observe(element);
    
    return () => {
      if (element) observer.unobserve(element);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [to]);
  
  const startAnimation = () => {
    // Clear any existing animation
    if (timerRef.current) clearInterval(timerRef.current);
    
    const increment = (to - from) / (duration / 16);
    const startTime = Date.now();
    
    timerRef.current = window.setInterval(() => {
      const elapsedTime = Date.now() - startTime;
      
      if (elapsedTime >= duration) {
        setCount(to);
        clearInterval(timerRef.current as number);
        return;
      }
      
      const progress = elapsedTime / duration;
      // Using easeOutQuad for smoother animation
      const easedProgress = -progress * (progress - 2);
      const nextCount = from + (to - from) * easedProgress;
      
      countRef.current = nextCount;
      setCount(Math.round(nextCount));
    }, 16);
  };

  return (
    <span id={`counter-${to}`}>
      {count}{suffix}
    </span>
  );
};