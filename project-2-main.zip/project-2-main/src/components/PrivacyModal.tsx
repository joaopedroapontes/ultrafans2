import React from 'react';
import { X } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="relative w-full max-w-4xl h-[90vh] bg-white rounded-xl shadow-2xl flex flex-col">
        <div className="sticky top-0 z-10 flex justify-between items-center p-4 border-b border-gray-200 bg-white rounded-t-xl">
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Política de Privacidade</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors p-2"
            aria-label="Fechar"
          >
            <X size={24} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="prose prose-sm sm:prose max-w-none text-gray-600">
            <p className="text-sm text-gray-500 mb-4">Última atualização: Março de 2025</p>
            
            <p className="mb-6">
              A Ultra Fans, operada por LLC Desenvolvimento Digital LTDA (CNPJ: 58.455.659/0001-12), respeita sua privacidade e está comprometida com a segurança e a transparência no tratamento dos seus dados pessoais.
            </p>
            
            <p className="mb-6">
              Este documento descreve como seus dados são coletados, usados, armazenados e protegidos ao utilizar nossa plataforma.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">1. Quais dados coletamos</h3>
            <p>
              A Ultra Fans coleta apenas os dados estritamente necessários para processar seu pedido:
            </p>
            <p>1.4. Rede social e serviço escolhido</p>
            <p>
              Esses dados são informados voluntariamente por você no momento do checkout, no ato da compra dos serviços.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">2. Como usamos os dados</h3>
            <p>Utilizamos seus dados para:</p>
            <p>2.1. Processar e identificar seu pagamento;</p>
            <p>
              2.2. Entregar corretamente os serviços solicitados (seguidores, curtidas, visualizações ou inscritos);
            </p>
            <p>2.3. Cumprir obrigações legais e fiscais.</p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">3. Armazenamento dos dados</h3>
            <p>
              Os dados fornecidos são armazenados de forma segura e por tempo indeterminado, com finalidade fiscal, jurídica e de controle de operação.
            </p>
            <p>
              Não armazenamos dados bancários, senhas, ou qualquer outro dado sensível além dos mencionados acima.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">4. Compartilhamento de dados</h3>
            <p>
              A Ultra Fans não compartilha, vende ou cede dados pessoais a terceiros.
            </p>
            <p>
              Os dados ficam restritos à equipe responsável pela operação técnica e atendimento da plataforma.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">5. Segurança da informação</h3>
            <p>
              Adotamos medidas técnicas e administrativas adequadas para proteger seus dados contra acessos não autorizados, destruição, perda, alteração ou qualquer forma de tratamento inadequado ou ilícito.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">6. Direitos dos titulares</h3>
            <p>Nos termos da LGPD, você tem os seguintes direitos:</p>
            <p>6.1. Confirmar a existência de tratamento dos seus dados;</p>
            <p>6.2. Solicitar acesso, correção, ou anonimização dos seus dados;</p>
            <p>6.3. Revogar o consentimento (quando aplicável);</p>
            <p>6.4. Solicitar a exclusão dos dados, caso permitido legalmente.</p>
            <p>
              Como não há criação de conta na plataforma, qualquer solicitação pode ser feita diretamente por e-mail.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">7. Contato</h3>
            <p>
              Para exercer seus direitos ou esclarecer dúvidas, entre em contato pelo e-mail:
            </p>
            <p>📩 suporte.ultrafans@gmail.com</p>
            
            <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">8. Atualizações desta Política</h3>
            <p>
              Esta Política poderá ser atualizada a qualquer momento, sem aviso prévio. A versão vigente estará sempre disponível nesta página.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};