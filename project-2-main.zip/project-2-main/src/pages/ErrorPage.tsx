import React from 'react';
import { Link } from 'react-router-dom';
import { XCircle } from 'lucide-react';

export const ErrorPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-950 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-xl p-8 text-center">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <XCircle className="w-8 h-8 text-red-500" />
        </div>
        
        <h1 className="text-2xl font-bold text-gray-900 mb-4">
          Ops! Algo deu errado
        </h1>
        
        <p className="text-gray-600 mb-8">
          Houve um problema ao processar seu pagamento. Por favor, tente novamente ou entre em contato com nosso suporte.
        </p>
        
        <div className="space-y-4">
          <Link
            to="/payment"
            className="inline-block w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all duration-200"
          >
            Tentar Novamente
          </Link>
          
          <Link
            to="/"
            className="inline-block w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-200 transition-all duration-200"
          >
            Voltar para a Home
          </Link>
        </div>
      </div>
    </div>
  );
};