import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Clock, Barcode as Qrcode, Shield, CheckCircle2, HeadphonesIcon, ChevronLeft, ChevronRight, Lock, ShieldCheck } from 'lucide-react';
import { testimonials } from '../data/testimonials';
import axios from 'axios';

const paymentSchema = z.object({
  email: z.string().email('Email inválido'),
});

type PaymentFormData = z.infer<typeof paymentSchema>;

export const PaymentPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [minutes, setMinutes] = useState(20);
  const [seconds, setSeconds] = useState(0);
  const [currentTestimonialIndex, setCurrentTestimonialIndex] = useState(0);
  const [qrCodeData, setQrCodeData] = useState<{ qr_code_url: string; qr_code: string } | null>(null);
  const [pixCode, setPixCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const pixInputRef = useRef<HTMLInputElement>(null);

  const { register, handleSubmit, formState: { errors } } = useForm<PaymentFormData>({
    resolver: zodResolver(paymentSchema),
  });

  useEffect(() => {
    if (!location.state) {
      navigate('/');
      return;
    }

    const timer = setInterval(() => {
      if (seconds > 0) {
        setSeconds(seconds - 1);
      } else if (minutes > 0) {
        setMinutes(minutes - 1);
        setSeconds(59);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [minutes, seconds, location.state, navigate]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonialIndex((prev) => 
        prev === testimonials.length - 1 ? 0 : prev + 1
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const nextTestimonial = () => {
    setCurrentTestimonialIndex((prev) =>
      prev === testimonials.length - 1 ? 0 : prev + 1
    );
  };

  const previousTestimonial = () => {
    setCurrentTestimonialIndex((prev) =>
      prev === 0 ? testimonials.length - 1 : prev - 1
    );
  };

  const onSubmit = async (data: PaymentFormData) => {
    if (!location.state) {
      navigate('/');
      return;
    }
    try {
      const { planTitle, amount, platform, username, price } = location.state;
      const payload = {
        customer: {
          email: data.email
        },
        planData: {
          title: planTitle,
          amount: amount,
          price: price,
          platform: platform,
          username: username,
          id: `${planTitle.toLowerCase()}_${platform}`
        }
      };
      const response = await axios.post('https://workflows.sucesse.com/webhook/create-order-pix', payload);
      console.log('PIX API response:', response.data);
      setQrCodeData({
        qr_code_url: response.data.qr_code,
        qr_code: response.data.qr_code
      });
      setPixCode(response.data.pix_copiaecola);
    } catch (error) {
      console.error('PIX error:', error);
      navigate('/error');
    }
  };

  if (!location.state) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-950 py-8">
      <div className="container mx-auto px-4">
        {/* Timer */}
        <div className="max-w-md mx-auto mb-8 bg-red-600 rounded-lg p-4 text-center">
          <div className="flex items-center justify-center gap-4">
            <Clock className="w-6 h-6 text-white" />
            <div className="text-white">
              <span className="text-2xl font-bold">
                {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
              </span>
              <p className="text-sm">Essa oferta expira em</p>
            </div>
          </div>
        </div>

        {/* Testimonials Carousel */}
        <div className="max-w-2xl mx-auto mb-8 bg-gray-800 rounded-xl p-4 sm:p-6">
          <div className="text-center relative">
            <button
              onClick={previousTestimonial}
              className="absolute left-0 top-1/2 -translate-y-1/2 bg-gray-700 hover:bg-gray-600 text-white rounded-full p-1.5 sm:p-2 transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={nextTestimonial}
              className="absolute right-0 top-1/2 -translate-y-1/2 bg-gray-700 hover:bg-gray-600 text-white rounded-full p-1.5 sm:p-2 transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight size={16} />
            </button>
            <blockquote className="text-white text-sm sm:text-lg mb-3 sm:mb-4 italic px-8 sm:px-12">
              "{testimonials[currentTestimonialIndex].comment}"
            </blockquote>
            <div className="flex items-center justify-center">
              <img
                src={testimonials[currentTestimonialIndex].avatar}
                alt={testimonials[currentTestimonialIndex].name}
                className="w-8 h-8 sm:w-12 sm:h-12 rounded-full mr-3"
              />
              <div className="text-left">
                <div className="font-semibold text-white text-sm sm:text-base">
                  {testimonials[currentTestimonialIndex].name}
                </div>
                <div className="text-xs sm:text-sm text-gray-400">
                  {testimonials[currentTestimonialIndex].profession}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Security Badges */}
        <div className="max-w-2xl mx-auto mb-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gray-800/50 rounded-lg p-3 sm:p-4 flex items-center gap-2 sm:gap-3">
            <Lock className="w-5 h-5 sm:w-6 sm:h-6 text-green-400" />
            <div>
              <p className="text-white text-xs sm:text-sm font-medium">Criptografia SSL</p>
              <p className="text-xs text-gray-400">Dados protegidos</p>
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-3 sm:p-4 flex items-center gap-2 sm:gap-3">
            <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-green-400" />
            <div>
              <p className="text-white text-xs sm:text-sm font-medium">Pagar.me</p>
              <p className="text-xs text-gray-400">Pagamento seguro</p>
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-3 sm:p-4 flex items-center gap-2 sm:gap-3">
            <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-green-400" />
            <div>
              <p className="text-white text-xs sm:text-sm font-medium">PCI Compliant</p>
              <p className="text-xs text-gray-400">Certificado PCI DSS</p>
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-3 sm:p-4 flex items-center gap-2 sm:gap-3">
            <Shield className="w-5 h-5 sm:w-6 sm:h-6 text-green-400" />
            <div>
              <p className="text-white text-xs sm:text-sm font-medium">Anti-Fraude</p>
              <p className="text-xs text-gray-400">Monitoramento 24/7</p>
            </div>
          </div>
        </div>

        {/* Payment Form - Apenas PIX */}
        <div className="max-w-md mx-auto bg-white rounded-xl shadow-xl overflow-hidden">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Finalizar Pedido</h2>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Email Field */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  {...register('email')}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="seu@email.com"
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              {!qrCodeData && (
                <div className="text-center text-gray-600 py-4">
                  Falta pouco! Basta finalizar o pagamento para garantir seus seguidores imediatamente.
                </div>
              )}

              {qrCodeData && pixCode && (
                <div className="text-center space-y-4">
                  <div className="flex flex-col items-center justify-center">
                    <div className="mb-2 text-lg font-semibold text-red-600 animate-pulse">
                      ⚡ Pague agora para garantir sua oferta exclusiva! O QR Code expira em poucos minutos.
                    </div>
                    <img
                      src={qrCodeData.qr_code_url}
                      alt="QR Code PIX"
                      className="mx-auto w-56 h-56 rounded-lg border-4 border-indigo-500 shadow-lg bg-white"
                    />
                  </div>
                  <div className="bg-gray-100 p-4 rounded-lg flex flex-col items-center">
                    <label className="text-sm text-gray-600 mb-2 font-semibold">Código PIX:</label>
                    <div className="w-full flex flex-col items-center">
                      <input
                        ref={pixInputRef}
                        type="text"
                        value={pixCode}
                        readOnly
                        className="w-full text-xs font-mono break-all bg-gray-200 rounded px-2 py-1 mb-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                        style={{ cursor: 'pointer' }}
                        onClick={() => {
                          pixInputRef.current?.select();
                        }}
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          await navigator.clipboard.writeText(pixCode);
                          setCopied(true);
                          setTimeout(() => setCopied(false), 2000);
                        }}
                        className={`inline-flex items-center gap-2 px-4 py-1.5 rounded bg-indigo-600 text-white text-xs font-semibold shadow hover:bg-indigo-700 transition-all ${copied ? 'bg-green-500' : ''}`}
                      >
                        {copied ? 'Copiado!' : 'Copiar código'}
                      </button>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    Após o pagamento, a confirmação é automática e você receberá seus seguidores em instantes.
                  </div>
                </div>
              )}

              {!qrCodeData && (
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all duration-200"
                >
                  Pagar
                </button>
              )}
            </form>
          </div>
        </div>

        {/* Guarantees */}
        <div className="max-w-2xl mx-auto mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-800 rounded-lg p-3 sm:p-4 text-center">
            <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-green-400 mx-auto mb-2" />
            <h3 className="text-white text-sm sm:text-base font-semibold mb-1">Compra 100% segura</h3>
            <p className="text-xs sm:text-sm text-gray-400">Seus dados estão protegidos</p>
          </div>
          <div className="bg-gray-800 rounded-lg p-3 sm:p-4 text-center">
            <CheckCircle2 className="w-6 h-6 sm:w-8 sm:h-8 text-green-400 mx-auto mb-2" />
            <h3 className="text-white text-sm sm:text-base font-semibold mb-1">Satisfação garantida</h3>
            <p className="text-xs sm:text-sm text-gray-400">7 dias de garantia ou dinheiro de volta</p>
          </div>
          <div className="bg-gray-800 rounded-lg p-3 sm:p-4 text-center">
            <HeadphonesIcon className="w-6 h-6 sm:w-8 sm:h-8 text-green-400 mx-auto mb-2" />
            <h3 className="text-white text-sm sm:text-base font-semibold mb-1">Suporte rápido</h3>
            <p className="text-xs sm:text-sm text-gray-400">Atendimento humano 24/7</p>
          </div>
        </div>
      </div>
    </div>
  );
};