import React from 'react';
import { Hero } from '../components/Hero';
import { Benefits } from '../components/Benefits';
import { PricingSection } from '../components/PricingSection';
import { Testimonials } from '../components/Testimonials';
import { HowItWorks } from '../components/HowItWorks';
import { FAQ } from '../components/FAQ';
import { SocialProof } from '../components/SocialProof';
import { Footer } from '../components/Footer';
import { RecentPurchase } from '../components/RecentPurchase';

export const HomePage: React.FC = () => {
  return (
    <>
      <RecentPurchase />
      <Hero />
      <Benefits />
      <PricingSection />
      <SocialProof />
      <Testimonials />
      <HowItWorks />
      <FAQ />
      <Footer />
    </>
  );
};