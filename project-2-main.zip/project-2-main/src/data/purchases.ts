interface Purchase {
  name: string;
  location: string;
  amount: number;
  type: string;
  platform: string;
}

const purchases: Purchase[] = [
  { name: 'João', location: 'SP', amount: 1000, type: 'seguidores', platform: 'Instagram' },
  { name: 'Maria', location: 'RJ', amount: 5000, type: 'curtidas', platform: 'Instagram' },
  { name: 'Pedro', location: 'MG', amount: 2000, type: 'seguidores', platform: 'TikTok' },
  { name: 'Ana', location: 'RS', amount: 10000, type: 'visualizações', platform: 'YouTube' },
  { name: 'Carlos', location: 'PR', amount: 500, type: 'seguidores', platform: 'X' },
  { name: 'Fernanda', location: 'BA', amount: 3000, type: 'curtidas', platform: 'TikTok' },
  { name: 'Ricardo', location: 'SC', amount: 1500, type: 'seguidores', platform: 'Instagram' },
  { name: 'Mariana', location: 'CE', amount: 4000, type: 'visualizações', platform: 'Instagram' },
  { name: 'Lucas', location: 'GO', amount: 2500, type: 'seguidores', platform: 'YouTube' },
  { name: 'Julia', location: 'PE', amount: 800, type: 'curtidas', platform: 'X' }
];

export const getRandomPurchase = (): Purchase => {
  return purchases[Math.floor(Math.random() * purchases.length)];
};