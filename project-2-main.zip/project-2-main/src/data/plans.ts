interface Plan {
  title: string;
  price: number;
  amount: number;
  features: string[];
  popular?: boolean;
  description: string;
  emoji: string;
  targetEmoji: string;
}

interface PlansByPlatform {
  instagram: Plan[];
  tiktok: Plan[];
  youtube: Plan[];
}

export const plans: PlansByPlatform = {
  instagram: [
    {
      title: 'Starter',
      price: 16.90,
      amount: 500,
      emoji: '🚀',
      targetEmoji: '🎯',
      description: 'Perfeito para quem está começando agora no Instagram e quer testar o impacto de seguidores reais sem gastar muito.',
      features: [
        'Entrega imediata',
        'Seguidores brasileiros e ativos',
        'Suporte ao cliente',
        'Garantia de reposição'
      ]
    },
    {
      title: 'Impulso',
      price: 24.90,
      amount: 1000,
      emoji: '⚡',
      targetEmoji: '🎨',
      description: 'Perfeito para criadores iniciantes, pequenos negócios e perfis que querem sair do zero e ganhar mais confiança visual rapidamente.',
      features: [
        'Entrega imediata',
        'Seguidores brasileiros e ativos',
        'Suporte prioritário',
        'Garantia de reposição'
      ]
    },
    {
      title: 'Influencer',
      price: 44.90,
      amount: 2000,
      emoji: '🌟',
      targetEmoji: '💫',
      description: 'Perfeito para criadores que buscam mais autoridade para atrair colaborações, engajamento orgânico e parcerias.',
      features: [
        'Entrega imediata',
        'Seguidores brasileiros e ativos',
        'Suporte VIP',
        'Garantia de reposição'
      ],
      popular: true
    },
    {
      title: 'Ultra',
      price: 59.90,
      amount: 3000,
      emoji: '💥',
      targetEmoji: '🏆',
      description: 'Perfeito para negócios locais, perfis comerciais ou infoprodutores que querem dar um salto de credibilidade nas redes.',
      features: [
        'Entrega imediata',
        'Seguidores brasileiros e ativos',
        'Suporte dedicado',
        'Garantia de reposição'
      ]
    },
    {
      title: 'Foguete',
      price: 99.90,
      amount: 5000,
      emoji: '🚀',
      targetEmoji: '💎',
      description: 'Perfeito para lançamentos, sorteios e campanhas promocionais que precisam de impacto imediato e prova social forte.',
      features: [
        'Entrega imediata',
        'Seguidores brasileiros e ativos',
        'Suporte prioritário',
        'Garantia de reposição'
      ]
    },
    {
      title: 'Meteoro',
      price: 199.90,
      amount: 10000,
      emoji: '☄️',
      targetEmoji: '👑',
      description: 'Perfeito para influenciadores profissionais, marcas pessoais e empresas que desejam escalar seu alcance e influência em alta velocidade.',
      features: [
        'Entrega imediata',
        'Seguidores brasileiros e ativos',
        'Suporte premium',
        'Garantia de reposição'
      ]
    }
  ],
  tiktok: [],
  youtube: []
};