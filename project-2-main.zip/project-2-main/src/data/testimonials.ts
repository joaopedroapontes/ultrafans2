interface Testimonial {
  name: string;
  profession: string;
  avatar: string;
  comment: string;
}

export const testimonials: Testimonial[] = [
  {
    name: 'Victor Mendes',
    profession: 'Empreendedor Digital',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600',
    comment: 'Depois de usar o serviço, meu perfil ganhou muito mais visibilidade. Consegui parcerias com marcas que antes nem olhavam para mim. Os seguidores são reais e ativos!'
  },
  {
    name: 'Marina Silva',
    profession: 'Nutricionista',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600',
    comment: 'Comprei um pacote para o meu Instagram e o resultado foi impressionante! Recebi os seguidores muito rápido e a qualidade é excelente. Com certeza vou comprar mais.'
  },
  {
    name: 'Ricardo Alves',
    profession: 'Social Media',
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=600',
    comment: 'Já tentei vários serviços semelhantes, mas este é o melhor! Seguidores reais, entrega rápida e um suporte ao cliente excelente. Recomendo a todos os criadores de conteúdo.'
  },
  {
    name: 'Julia Santos',
    profession: 'Influenciadora Local',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
    comment: 'Meu Instagram estava parado há meses. Depois de usar o serviço, os seguidores começaram a chegar, o engajamento aumentou naturalmente e até voltei a aparecer no Explorar. Valeu muito a pena!'
  },
  {
    name: 'Fernando Costa',
    profession: 'Personal Trainer',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=600',
    comment: 'O melhor investimento que fiz para minha marca pessoal. Tudo funcionou como prometido e agora tenho muito mais autoridade no meu nicho. Obrigado pelo excelente serviço!'
  },
  {
    name: 'Amanda Oliveira',
    profession: 'Psicóloga',
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=600',
    comment: 'Serviço incrível! Tinha receio no início, mas foi tudo muito transparente e seguro. Depois da compra, meu perfil ganhou força, atraí novos seguidores reais e até fui convidada para uma live!!'
  }
];