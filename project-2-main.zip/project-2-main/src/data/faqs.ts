interface FAQ {
  question: string;
  answer: string;
}

export const faqs: FAQ[] = [
  {
    question: 'Em quanto tempo recebo meus seguidores e curtidas?',
    answer: 'Seu pedido começa a ser entregue em poucos minutos após a confirmação do pagamento. Dependendo da quantidade escolhida, para volumes muito grandes, pode demorar até 24 horas para a entrega completa.'
  },
  {
    question: 'Preciso informar minha senha?',
    answer: 'Não! Basta digitar o link ou @ do seu usuário.'
  },
  {
    question: 'É seguro comprar seguidores?',
    answer: '100% seguro. Nunca pedimos informações sensíveis e confidenciais como senha e e-mail da conta, além de sermos uma plataforma protegida por um certificado de segurança SSL.'
  },
  {
    question: 'É comum comprar seguidores?',
    answer: 'É uma prática extremamente comum. Milhares de pessoas compram seguidores, principalmente quando estão começando, porque comprando você alcançará grande relevância em pouco tempo. É por isso que muitos perfis pessoais e comerciais utilizam a estratégia de comprar seguidores para crescer rapidamente.'
  },
  {
    question: 'Quantos seguidores posso comprar?',
    answer: 'Você pode comprar quantos seguidores desejar. A quantidade depende exclusivamente de você, das suas condições e objetivos que deseja conquistar. Temos diversos pacotes com diferentes quantidades que você pode adquirir.'
  },
  {
    question: 'Minha conta pode ser bloqueada?',
    answer: 'Não! O risco de ter conta bloqueada é zero. Trabalhamos com a mais alta tecnologia e soluções em marketing, garantindo uma entrega 100% segura e respeitando as políticas de cada rede social.'
  },
  {
    question: 'Preciso seguir os seguidores de volta?',
    answer: 'Não! Você não precisa seguir ninguém de volta. Após finalizar a compra em nosso site, você precisa apenas aguardar a começar a receber os seguidores.'
  },
  {
    question: 'Meu perfil pode estar privado?',
    answer: 'Não, para que você comece a receber os seguidores comprados seu perfil deve estar público. Depois de recebê-los, você pode voltar a tornar seu perfil privado, caso deseje.'
  },
  {
    question: 'Quais são as opções de pagamento?',
    answer: 'Os pagamentos poderão ser realizados via PIX, Cartão de Crédito, Boleto, PicPay, ApplePay e GooglePay.'
  },
  {
    question: 'Existe alguma garantia?',
    answer: 'Nossa garantia é de 30 dias após a compra, 4 vezes maior que o exigido por lei. Além disso, você contará com uma rápida equipe de suporte todos os dias, das 09h às 22h.'
  },
  {
    question: 'Por que usar a Ultra Fans?',
    answer: 'Somos uma plataforma especializada em crescimento e engajamento nas redes sociais. Em mais de 4 anos de atuação, construímos uma reputação sólida baseada em resultados reais, rapidez, facilidade, segurança e atendimento de qualidade.'
  }
];